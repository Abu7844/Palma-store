import { z } from "zod";

export const checkoutSchema = z.object({
  name: z.string().trim().min(2).max(120),
  phone: z.string().trim().min(7).max(30),
  email: z.string().trim().email().optional().or(z.literal("")),
  country: z.string().trim().min(2).max(100),
  city: z.string().trim().min(1).max(100),
  fullAddress: z.string().trim().min(5).max(500),
  postalCode: z.string().trim().max(30).optional(),
  comment: z.string().trim().max(1000).optional(),
  promoCode: z.string().trim().max(80).optional(),
  currency: z.enum(["UZS", "USD", "SAR"]),
  paymentMethod: z.enum(["CASH", "VISA", "UZCARD", "PAYME", "CLICK"]),
  items: z.array(z.object({
    productId: z.string().min(1),
    quantity: z.number().int().min(1).max(100)
  })).min(1).max(50)
}).superRefine((value, ctx) => {
  const ids = value.items.map(item => item.productId);
  if (new Set(ids).size !== ids.length) {
    ctx.addIssue({ code: "custom", message: "Duplicate product IDs are not allowed", path: ["items"] });
  }
});
