import { createHmac, timingSafeEqual } from "node:crypto";

export type TelegramWebAppUser = {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
};

export function verifyTelegramInitData(initData: string): TelegramWebAppUser | null {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token || !initData) return null;

  const params = new URLSearchParams(initData);
  const receivedHash = params.get("hash");
  const authDate = Number(params.get("auth_date"));
  if (!receivedHash || !Number.isFinite(authDate)) return null;

  // Reject stale or future-dated Telegram launch payloads.
  const now = Math.floor(Date.now() / 1000);
  if (authDate > now + 60 || now - authDate > 60 * 60 * 24) return null;

  params.delete("hash");
  params.delete("signature");
  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");

  const secretKey = createHmac("sha256", "WebAppData").update(token).digest();
  const calculatedHash = createHmac("sha256", secretKey).update(dataCheckString).digest();
  let supplied: Buffer;
  try {
    supplied = Buffer.from(receivedHash, "hex");
  } catch {
    return null;
  }
  if (supplied.length !== calculatedHash.length || !timingSafeEqual(supplied, calculatedHash)) return null;

  try {
    const rawUser = params.get("user");
    if (!rawUser) return null;
    const user = JSON.parse(rawUser) as TelegramWebAppUser;
    if (!Number.isSafeInteger(user.id) || user.id <= 0 || !user.first_name) return null;
    return user;
  } catch {
    return null;
  }
}
