import type { OnlineProvider, PaymentProviderAdapter, PaymentStartResult } from "./types";

/**
 * Provider-specific API contracts differ. Never invent checkout URLs or
 * accept a browser-supplied "paid" flag. Implement each adapter only against
 * the merchant's official production/sandbox documentation.
 */
class NotConfiguredAdapter implements PaymentProviderAdapter {
  constructor(public provider: OnlineProvider) {}
  async start(): Promise<PaymentStartResult> {
    return {
      configured: false,
      reason: `${this.provider} учун расмий провайдер адаптери ва merchant endpoint ҳали уланмаган.`
    };
  }
}

export function getPaymentAdapter(provider: OnlineProvider): PaymentProviderAdapter {
  const supported: OnlineProvider[] = ["PAYME", "CLICK", "UZCARD", "VISA"];
  if (!supported.includes(provider)) throw new Error("UNSUPPORTED_PROVIDER");
  return new NotConfiguredAdapter(provider);
}
