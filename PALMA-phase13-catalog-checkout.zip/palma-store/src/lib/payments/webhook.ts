import { createHmac, timingSafeEqual } from "node:crypto";

export type PaymentWebhookEvent = {
  eventId: string;
  transactionId: string;
  provider: "PAYME" | "CLICK" | "UZCARD" | "VISA";
  status: "PAID" | "FAILED";
  amount: number;
  currency: string;
};

export function verifyPaymentWebhook(rawBody: string, signature: string | null) {
  const secret = process.env.PALMA_PAYMENT_WEBHOOK_SECRET;
  if (!secret || !signature) return false;
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(signature.trim().toLowerCase());
  return a.length === b.length && timingSafeEqual(a, b);
}
