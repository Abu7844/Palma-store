export type OnlineProvider = "PAYME" | "CLICK" | "UZCARD" | "VISA";
export type PaymentStartResult =
  | { configured: true; checkoutUrl: string; providerReference?: string }
  | { configured: false; reason: string };

export interface PaymentProviderAdapter {
  provider: OnlineProvider;
  start(input: {
    orderId: string;
    orderNumber: string;
    amountMinor: number;
    currency: string;
    returnUrl: string;
  }): Promise<PaymentStartResult>;
}
