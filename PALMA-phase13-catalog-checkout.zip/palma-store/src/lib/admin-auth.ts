import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";

export type StaffRole = "OWNER" | "ADMIN" | "OPERATOR" | "COURIER" | "ACCOUNTANT";

export async function requireRoles(allowed: StaffRole[]) {
  const user = await getCurrentUser();
  if (!user) return { user: null, response: NextResponse.json({ error: "Аввал тизимга киринг." }, { status: 401 }) };
  if (!user.isActive) return { user: null, response: NextResponse.json({ error: "Ҳисоб блокланган." }, { status: 403 }) };
  if (!allowed.includes(user.role as StaffRole)) {
    return { user: null, response: NextResponse.json({ error: "Бу амал учун рухсат йўқ." }, { status: 403 }) };
  }
  return { user, response: null };
}

// General administration: owner/admin. Use narrower roles for sensitive actions.
export async function requireAdmin() {
  const result = await requireRoles(["OWNER", "ADMIN"]);
  return result.response;
}

export async function requireOwner() {
  const result = await requireRoles(["OWNER"]);
  return result.response;
}

export async function requireOrderStaff() {
  const result = await requireRoles(["OWNER", "ADMIN", "OPERATOR"]);
  return result.response;
}
