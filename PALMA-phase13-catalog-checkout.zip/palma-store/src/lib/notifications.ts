import type { PalmaLocale } from "./i18n";
const statusText: Record<PalmaLocale, Record<string,string>> = {
  uz: { NEW:"Янги", CONFIRMED:"Тасдиқланди", PREPARING:"Тайёрланмоқда", SHIPPING:"Йўлда", DELIVERED:"Етказилди", CANCELLED:"Бекор қилинди" },
  ru: { NEW:"Новый", CONFIRMED:"Подтверждён", PREPARING:"Готовится", SHIPPING:"В пути", DELIVERED:"Доставлен", CANCELLED:"Отменён" },
  en: { NEW:"New", CONFIRMED:"Confirmed", PREPARING:"Preparing", SHIPPING:"On the way", DELIVERED:"Delivered", CANCELLED:"Cancelled" },
  ar: { NEW:"جديد", CONFIRMED:"تم التأكيد", PREPARING:"قيد التجهيز", SHIPPING:"في الطريق", DELIVERED:"تم التسليم", CANCELLED:"ملغي" }
};
export function orderStatusMessage(locale: string | null | undefined, orderNumber: string, status: string) {
  const lang = (["uz","ru","en","ar"].includes(locale || "") ? locale : "uz") as PalmaLocale;
  const label = statusText[lang][status] || status;
  const templates: Record<PalmaLocale,string> = {
    uz:`PALMA буюртмангиз ${orderNumber}: ${label}.`,
    ru:`Ваш заказ PALMA ${orderNumber}: ${label}.`,
    en:`Your PALMA order ${orderNumber}: ${label}.`,
    ar:`طلب PALMA رقم ${orderNumber}: ${label}.`
  };
  return templates[lang];
}
export async function sendTelegramMessage(chatId: string, message: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method:"POST", headers:{"content-type":"application/json"},
      body:JSON.stringify({chat_id:chatId,text:message})
    });
    return response.ok;
  } catch { return false; }
}
