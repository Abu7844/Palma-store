export type PalmaLocale = "uz" | "ru" | "en" | "ar";
export const supportedLocales: PalmaLocale[] = ["uz", "ru", "en", "ar"];
export const dictionaries = {
  uz: { home:"Бош саҳифа", catalog:"Каталог", orders:"Буюртмаларим", support:"Ёрдам", cart:"Сават", search:"Қидириш", orderStatus:"Буюртма ҳолати" },
  ru: { home:"Главная", catalog:"Каталог", orders:"Мои заказы", support:"Поддержка", cart:"Корзина", search:"Поиск", orderStatus:"Статус заказа" },
  en: { home:"Home", catalog:"Catalog", orders:"My orders", support:"Support", cart:"Cart", search:"Search", orderStatus:"Order status" },
  ar: { home:"الرئيسية", catalog:"الكتالوج", orders:"طلباتي", support:"الدعم", cart:"السلة", search:"بحث", orderStatus:"حالة الطلب" }
} satisfies Record<PalmaLocale, Record<string,string>>;

export function normalizeLocale(value?: string | null): PalmaLocale {
  return supportedLocales.includes(value as PalmaLocale) ? value as PalmaLocale : "uz";
}
export function direction(locale: PalmaLocale) { return locale === "ar" ? "rtl" : "ltr"; }
export function text(locale: PalmaLocale, key: keyof typeof dictionaries.uz) {
  return dictionaries[locale][key] || dictionaries.uz[key];
}
