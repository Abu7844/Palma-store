"use client";
import { useEffect, useState } from "react";

type Staff = { id:string; name:string|null; email:string|null; phone:string|null; telegramId:string|null; role:string; isActive:boolean };
const roles = ["OWNER","ADMIN","OPERATOR","COURIER","ACCOUNTANT","CUSTOMER"];
export default function StaffPage() {
  const [users,setUsers]=useState<Staff[]>([]);
  const [message,setMessage]=useState("");
  async function load() {
    const r=await fetch("/api/admin/staff");
    const d=await r.json();
    if(r.ok) setUsers(d.users); else setMessage(d.error || "Ходимларни юклаб бўлмади.");
  }
  async function update(userId:string, patch:object) {
    const r=await fetch("/api/admin/staff",{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({userId,...patch})});
    const d=await r.json(); setMessage(r.ok?"Ўзгариш сақланди.":d.error||"Хатолик");
    if(r.ok) await load();
  }
  useEffect(()=>{void load()},[]);
  return <main style={{maxWidth:1000,margin:"40px auto",padding:20,fontFamily:"Arial"}}>
    <h1>PALMA — Ходимлар ва ҳуқуқлар</h1>
    <p>Бу саҳифа фақат OWNER ролига очиқ. Ходим аввал Telegram орқали камида бир марта кирган бўлиши керак.</p>
    {message&&<p role="status">{message}</p>}
    <button onClick={()=>void load()}>Янгилаш</button>
    <div style={{overflowX:"auto"}}>
      <table style={{width:"100%",borderCollapse:"collapse",marginTop:16}}>
        <thead><tr><th align="left">Ходим</th><th align="left">Алоқа</th><th>Роль</th><th>Ҳолат</th></tr></thead>
        <tbody>{users.map(u=><tr key={u.id} style={{borderTop:"1px solid #ddd"}}>
          <td>{u.name||"—"}<small style={{display:"block"}}>{u.id}</small></td>
          <td>{u.phone||u.email||u.telegramId||"—"}</td>
          <td><select value={u.role} onChange={e=>void update(u.id,{role:e.target.value})}>{roles.map(r=><option key={r}>{r}</option>)}</select></td>
          <td><button onClick={()=>void update(u.id,{isActive:!u.isActive})}>{u.isActive?"Фаол":"Блокланган"} · ўзгартириш</button></td>
        </tr>)}</tbody>
      </table>
    </div>
  </main>;
}
