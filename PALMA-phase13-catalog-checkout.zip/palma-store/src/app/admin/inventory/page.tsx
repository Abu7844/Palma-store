"use client";
import { useEffect, useState } from "react";

type Stock = {
  id: string; quantity: number; lowStockThreshold: number;
  warehouse: { id: string; name: string; country: string; city: string };
  product: { id: string; nameUz: string; sku: string };
};
type Warehouse = { id: string; name: string; country: string; city: string };

export default function InventoryPage() {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [message, setMessage] = useState("");
  const [warehouseId, setWarehouseId] = useState("");
  const [productId, setProductId] = useState("");
  const [delta, setDelta] = useState("1");
  const [threshold, setThreshold] = useState("5");

  async function load() {
    const [i, w] = await Promise.all([
      fetch("/api/admin/inventory"),
      fetch("/api/admin/warehouses"),
    ]);
    if (i.ok && w.ok) {
      const inventory = await i.json(); const warehouseData = await w.json();
      setStocks(inventory.stocks); setWarehouses(warehouseData.warehouses);
      if (!warehouseId && warehouseData.warehouses[0]) setWarehouseId(warehouseData.warehouses[0].id);
    } else setMessage("Кириш калити ёки сервер жавобини текширинг.");
  }
  useEffect(() => { void load(); }, []);

  async function adjust(e: React.FormEvent) {
    e.preventDefault(); setMessage("");
    const res = await fetch("/api/admin/inventory", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ warehouseId, productId, delta: Number(delta), lowStockThreshold: Number(threshold) }),
    });
    const data = await res.json();
    setMessage(res.ok ? "Омбор қолдиғи янгиланди." : data.error ?? "Хатолик");
    if (res.ok) await load();
  }

  return <main style={{maxWidth:1000,margin:"40px auto",padding:20,fontFamily:"Arial"}}>
    <h1>PALMA — Омбор ва қолдиқлар</h1>
    {message && <p role="status">{message}</p>}
    <h2>Қолдиқни кирим/чиқим қилиш</h2>
    <form onSubmit={adjust} style={{display:"grid",gap:10,maxWidth:500}}>
      <select value={warehouseId} onChange={e=>setWarehouseId(e.target.value)} required>
        <option value="">Омборни танланг</option>{warehouses.map(w=><option key={w.id} value={w.id}>{w.name} — {w.city}, {w.country}</option>)}
      </select>
      <input value={productId} onChange={e=>setProductId(e.target.value)} placeholder="Product ID" required />
      <input type="number" value={delta} onChange={e=>setDelta(e.target.value)} placeholder="+ кирим / - чиқим" required />
      <input type="number" min="0" value={threshold} onChange={e=>setThreshold(e.target.value)} placeholder="Кам қолдиқ чегараси" required />
      <button type="submit">Сақлаш</button>
    </form>
    <h2>Омбордаги маҳсулотлар</h2>
    <button onClick={()=>void load()}>Янгилаш</button>
    <div style={{overflowX:"auto"}}>
      <table style={{width:"100%",borderCollapse:"collapse",marginTop:12}}>
        <thead><tr><th align="left">Маҳсулот</th><th align="left">Омбор</th><th>Қолдиқ</th><th>Чегара</th><th>Ҳолат</th></tr></thead>
        <tbody>{stocks.map(s=><tr key={s.id} style={{borderTop:"1px solid #ddd"}}>
          <td>{s.product.nameUz} ({s.product.sku})</td><td>{s.warehouse.name}, {s.warehouse.city}</td>
          <td align="center">{s.quantity}</td><td align="center">{s.lowStockThreshold ?? 5}</td>
          <td align="center">{s.quantity <= (s.lowStockThreshold ?? 5) ? "Кам қолдиқ" : "Етарли"}</td>
        </tr>)}</tbody>
      </table>
    </div>
  </main>;
}
