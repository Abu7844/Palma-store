import { AdminProducts } from "@/components/admin-products";
import { AdminOrders } from "@/components/admin-orders";

export default function AdminPage() {
  return <main className="shell" style={{paddingTop:35,paddingBottom:60}}>
    <a className="brand" href="/">PALMA<span>.</span></a>
    <h1 style={{fontFamily:"Manrope",marginTop:30}}>PALMA бошқарув панели</h1>
    <p style={{color:"var(--muted)"}}>Маҳсулотлар ва буюртмалар бошқаруви.</p>
    <div style={{display:"grid",gap:24,marginTop:25}}>
      <AdminOrders />
      <AdminProducts />
    </div>
  </main>;
}
