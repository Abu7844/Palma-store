"use client";
import {useEffect,useState} from "react";
type Review={id:string;rating:number;body:string|null;isApproved:boolean;product:{nameUz:string};user:{name:string|null};createdAt:string};
export default function ReviewsPage(){
 const [items,setItems]=useState<Review[]>([]);const [error,setError]=useState("");
 async function load(){const r=await fetch("/api/admin/reviews");const d=await r.json();if(r.ok)setItems(d.reviews);else setError(d.error||"Хатолик");}
 async function approve(id:string,isApproved:boolean){const r=await fetch("/api/admin/reviews",{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({id,isApproved})});if(!r.ok){const d=await r.json();setError(d.error||"Хатолик")}await load();}
 useEffect(()=>{void load()},[]);
 return <main style={{maxWidth:900,margin:"40px auto",padding:20,fontFamily:"Arial"}}><h1>PALMA — Шарҳлар модерацияси</h1>{error&&<p>{error}</p>}{items.map(x=><article key={x.id} style={{borderBottom:"1px solid #ddd",padding:14}}><b>{x.product.nameUz}</b> · {"★".repeat(x.rating)}<p>{x.body}</p><small>{x.user.name||"Мижоз"} · {new Date(x.createdAt).toLocaleDateString()}</small><p><button onClick={()=>void approve(x.id,!x.isApproved)}>{x.isApproved?"Яшириш":"Тасдиқлаш"}</button></p></article>)}</main>
}
