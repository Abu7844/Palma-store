import { TelegramLogin } from "@/components/telegram-login";
export default function AccountPage(){return <main className="shell" style={{paddingTop:40,paddingBottom:60}}><a className="brand" href="/">PALMA<span>.</span></a><TelegramLogin /></main>}
