"use client";
import { useEffect, useState } from "react";
type Order = { id:string; orderNumber:string; status:string; total:string|number; currency:string; createdAt:string; items:{id:string;productName:string;quantity:number}[] };
const labels:Record<string,string>={NEW:"Янги",CONFIRMED:"Тасдиқланди",PREPARING:"Тайёрланмоқда",SHIPPING:"Йўлда",DELIVERED:"Етказилди",CANCELLED:"Бекор қилинди"};
export default function OrdersPage(){
 const [orders,setOrders]=useState<Order[]>([]); const [message,setMessage]=useState("Юкланмоқда...");
 useEffect(()=>{fetch("/api/my-orders").then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.error);setOrders(d.orders);setMessage(d.orders.length?"":"Ҳозирча буюртмалар йўқ.");}).catch(e=>setMessage(e instanceof Error?e.message:"Маълумотни олиб бўлмади"));},[]);
 return <main className="shell" style={{paddingTop:35,paddingBottom:60}}><a className="brand" href="/">PALMA<span>.</span></a><h1 style={{fontFamily:"Manrope",marginTop:30}}>Буюртмаларим</h1>{orders.length===0?<div className="emptyState">{message}</div>:<div className="myOrderList">{orders.map(o=><article className="orderCard" key={o.id}><div className="orderTop"><div><b>{o.orderNumber}</b><small>{new Date(o.createdAt).toLocaleString()}</small></div><strong>{Number(o.total).toLocaleString()} {o.currency}</strong></div><p>Ҳолати: <b>{labels[o.status]||o.status}</b></p><ul>{o.items.map(i=><li key={i.id}>{i.productName} × {i.quantity}</li>)}</ul></article>)}</div>}</main>
}
