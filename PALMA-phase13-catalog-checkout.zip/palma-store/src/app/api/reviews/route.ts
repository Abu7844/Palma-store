import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

const schema = z.object({
  productId: z.string().min(1),
  orderId: z.string().min(1),
  rating: z.number().int().min(1).max(5),
  body: z.string().trim().max(2000).optional(),
  photoUrls: z.array(z.string().url()).max(4).default([])
});

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const productId = searchParams.get("productId");
  if (!productId) return NextResponse.json({ error:"productId керак." }, {status:400});
  const reviews = await prisma.review.findMany({
    where:{productId,isApproved:true},
    select:{id:true,rating:true,body:true,photoUrls:true,createdAt:true,user:{select:{name:true}}},
    orderBy:{createdAt:"desc"},take:100
  });
  return NextResponse.json({reviews});
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({error:"Аввал тизимга киринг."},{status:401});
  const parsed=schema.safeParse(await request.json().catch(()=>null));
  if(!parsed.success) return NextResponse.json({error:"Шарҳ маълумотлари нотўғри."},{status:400});
  const d=parsed.data;
  const verified=await prisma.order.findFirst({
    where:{id:d.orderId,userId:user.id,status:"DELIVERED",items:{some:{productId:d.productId}}},
    select:{id:true}
  });
  if(!verified) return NextResponse.json({error:"Фақат шу маҳсулотни сотиб олиб, қабул қилган мижоз шарҳ қолдириши мумкин."},{status:403});
  try {
    const review=await prisma.review.create({data:{
      userId:user.id,productId:d.productId,orderId:d.orderId,rating:d.rating,
      body:d.body,photoUrls:d.photoUrls,isApproved:false
    }});
    return NextResponse.json({review,message:"Шарҳ модерациядан кейин кўринади."},{status:201});
  } catch {
    return NextResponse.json({error:"Бу буюртма учун шарҳ аввал юборилган ёки маълумотлар нотўғри."},{status:409});
  }
}
