import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { prisma } from "@/lib/prisma";
import { checkoutSchema } from "@/lib/validation";

async function notifyAdmin(message: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.ADMIN_TELEGRAM_CHAT_ID;
  if (!token || !chatId) return;
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: message })
    });
  } catch {
    // Notification failure must not undo a successfully placed order.
  }
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Маълумотлар нотўғри", details: parsed.error.flatten() }, { status: 400 });
  }

  const input = parsed.data;
  try {
    const order = await prisma.$transaction(async (tx) => {
      const products = await tx.product.findMany({
        where: { id: { in: input.items.map(i => i.productId) }, isActive: true },
        include: { stockItems: true }
      });

      if (products.length !== input.items.length) {
        throw new Error("PRODUCT_UNAVAILABLE");
      }

      const warehouseRows = await tx.warehouse.findMany({ where: { isActive: true } });
      const warehousesById = new Map(warehouseRows.map(w => [w.id, w]));

      let subtotal = 0;
      const orderItems = input.items.map((item) => {
        const product = products.find(p => p.id === item.productId);
        if (!product) throw new Error("PRODUCT_UNAVAILABLE");
        if (product.currency !== input.currency) throw new Error("CURRENCY_MISMATCH");

        const available = product.stockItems.reduce((sum, stock) => sum + stock.quantity, 0);
        if (available < item.quantity) throw new Error("OUT_OF_STOCK");

        const unitPrice = Number(product.price);
        if (!Number.isFinite(unitPrice) || unitPrice <= 0) throw new Error("INVALID_PRODUCT_PRICE");
        subtotal += unitPrice * item.quantity;

        return {
          productId: product.id,
          productName: product.nameUz,
          quantity: item.quantity,
          unitPrice
        };
      });

      const delivery = await tx.deliveryRate.findUnique({
        where: { country_city: { country: input.country, city: input.city } }
      });
      if (!delivery || !delivery.isActive) throw new Error("DELIVERY_UNAVAILABLE");
      if (delivery.currency !== input.currency) throw new Error("DELIVERY_CURRENCY_MISMATCH");

      const phone = input.phone;
      const user = await tx.user.upsert({
        where: { phone },
        update: {
          name: input.name,
          email: input.email || undefined,
          preferredLang: "uz"
        },
        create: {
          phone,
          name: input.name,
          email: input.email || undefined,
          preferredLang: "uz"
        }
      });


      // Prefer the warehouse in the destination city, then the same country.
      // Without customer coordinates, this is a location-based fallback, not GPS distance.
      const allocations: Array<{ warehouseId: string; productId: string; quantity: number }> = [];
      for (const item of input.items) {
        let remaining = item.quantity;
        const product = products.find(p => p.id === item.productId)!;
        const stocks = [...product.stockItems].sort((a, b) => {
          const wa = warehousesById.get(a.warehouseId);
          const wb = warehousesById.get(b.warehouseId);
          const score = (w: any) => !w ? 3 : w.city.toLocaleLowerCase() === input.city.toLocaleLowerCase()
            && w.country.toLocaleLowerCase() === input.country.toLocaleLowerCase() ? 0
            : w.country.toLocaleLowerCase() === input.country.toLocaleLowerCase() ? 1 : 2;
          return score(wa) - score(wb) || b.quantity - a.quantity;
        });

        for (const stock of stocks) {
          if (remaining <= 0) break;
          const take = Math.min(stock.quantity, remaining);
          if (take <= 0) continue;
          const changed = await tx.warehouseStock.updateMany({
            where: { id: stock.id, quantity: { gte: take } },
            data: { quantity: { decrement: take } }
          });
          if (changed.count !== 1) throw new Error("STOCK_RACE");
          remaining -= take;
          allocations.push({ warehouseId: stock.warehouseId, productId: item.productId, quantity: take });
          await tx.stockMovement.create({
            data: {
              warehouseId: stock.warehouseId,
              productId: item.productId,
              quantity: -take,
              type: "OUT",
              note: "Order checkout — automatic warehouse allocation"
            }
          });
        }
        if (remaining > 0) throw new Error("OUT_OF_STOCK");
      }

      let promotionId: string | undefined;
      let discount = 0;
      if (input.promoCode) {
        const promotion = await tx.promotion.findUnique({ where: { code: input.promoCode } });
        const now = new Date();
        if (!promotion || !promotion.isActive ||
            (promotion.startsAt && promotion.startsAt > now) ||
            (promotion.endsAt && promotion.endsAt < now) ||
            !promotion.percentOff || promotion.percentOff < 1 || promotion.percentOff > 100) {
          throw new Error("PROMO_INVALID");
        }
        promotionId = promotion.id;
        discount = Math.round(subtotal * promotion.percentOff / 100 * 100) / 100;
      }

      const shippingPrice = Number(delivery.price);
      const orderNumber = `PL-${Date.now().toString(36).toUpperCase()}-${randomBytes(3).toString("hex").toUpperCase()}`;
      const createdOrder = await tx.order.create({
        data: {
          orderNumber,
          userId: user.id,
          paymentMethod: input.paymentMethod,
          paymentStatus: "PENDING",
          currency: input.currency,
          subtotal,
          shippingPrice,
          total: Math.max(0, subtotal - discount) + shippingPrice,
          discount,
          promotionId,
          country: input.country,
          city: input.city,
          fullAddress: input.fullAddress,
          postalCode: input.postalCode || undefined,
          customerComment: input.comment || undefined,
          items: { create: orderItems }
        },
        include: { items: true }
      });
      if (allocations.length) {
        await tx.orderFulfillment.createMany({
          data: allocations.map(a => ({ ...a, orderId: createdOrder.id }))
        });
      }
      return createdOrder;

    });

    const adminMessage = [
      "🛍 PALMA — Янги буюртма",
      `Рақам: ${order.orderNumber}`,
      `Мижоз: ${input.name}`,
      `Телефон: ${input.phone}`,
      `Манзил: ${input.country}, ${input.city}`,
      `Сумма: ${Number(order.total).toLocaleString()} ${order.currency}`,
      `Тўлов: ${input.paymentMethod}`
    ].join("\n");
    await notifyAdmin(adminMessage);

    return NextResponse.json({
      ok: true,
      order: {
        id: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        currency: order.currency,
        subtotal: Number(order.subtotal),
        shippingPrice: Number(order.shippingPrice),
        total: Number(order.total)
      }
    }, { status: 201 });
  } catch (error) {
    const code = error instanceof Error ? error.message : "";
    const messages: Record<string, string> = {
      PRODUCT_UNAVAILABLE: "Айрим маҳсулотлар мавжуд эмас.",
      CURRENCY_MISMATCH: "Маҳсулот валютаси танланган валютага мос эмас.",
      OUT_OF_STOCK: "Омборда маҳсулот етарли эмас.",
      INVALID_PRODUCT_PRICE: "Маҳсулот нархи тўғри белгиланмаган.",
      DELIVERY_UNAVAILABLE: "Бу шаҳар учун етказиб бериш тарифи ҳали белгиланмаган.",
      DELIVERY_CURRENCY_MISMATCH: "Етказиб бериш валютаси мос эмас.",
      PROMO_INVALID: "Промокод нотўғри, муддати ўтган ёки фаол эмас.",
      STOCK_RACE: "Омбор қолдиғи ўзгарди. Илтимос, қайта уриниб кўринг."
    };
    return NextResponse.json({ error: messages[code] || "Буюртмани сақлашда хатолик юз берди." }, { status: 400 });
  }
}
