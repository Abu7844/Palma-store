import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Аввал тизимга киринг." }, { status: 401 });
  if (user.role !== "COURIER") return NextResponse.json({ error: "Курьер рухсати талаб қилинади." }, { status: 403 });

  const assignments = await prisma.courierAssignment.findMany({
    where: { courierId: user.id },
    include: {
      // Order and customer details are fetched below to keep response explicit.
    },
    orderBy: { assignedAt: "desc" }
  });

  const orders = await Promise.all(assignments.map(async assignment => {
    const order = await prisma.order.findUnique({
      where: { id: assignment.orderId },
      include: {
        user: { select: { name: true, phone: true } },
        items: true
      }
    });
    return order ? { assignment, order } : null;
  }));

  return NextResponse.json({ orders: orders.filter(Boolean) });
}
