import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  status: z.enum(["SHIPPING", "DELIVERED"]),
  proofPhoto: z.string().url().optional(),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional()
});

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Аввал тизимга киринг." }, { status: 401 });
  if (user.role !== "COURIER") return NextResponse.json({ error: "Курьер рухсати талаб қилинади." }, { status: 403 });

  const { id } = await context.params;
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Маълумотлар нотўғри." }, { status: 400 });

  const assignment = await prisma.courierAssignment.findUnique({ where: { orderId: id } });
  if (!assignment || assignment.courierId !== user.id) {
    return NextResponse.json({ error: "Бу буюртма сизга бириктирилмаган." }, { status: 403 });
  }

  const order = await prisma.order.findUnique({ where: { id } });
  if (!order) return NextResponse.json({ error: "Буюртма топилмади." }, { status: 404 });

  const nextStatus = parsed.data.status;
  if (nextStatus === "SHIPPING" && !["CONFIRMED", "PREPARING", "SHIPPING"].includes(order.status)) {
    return NextResponse.json({ error: "Буюртмани етказишга чиқариш мумкин эмас." }, { status: 409 });
  }
  if (nextStatus === "DELIVERED" && order.status !== "SHIPPING") {
    return NextResponse.json({ error: "Аввал буюртмани йўлда деб белгиланг." }, { status: 409 });
  }
  if (nextStatus === "DELIVERED" && !parsed.data.proofPhoto) {
    return NextResponse.json({ error: "Етказилганини тасдиқлаш учун фото URL керак." }, { status: 400 });
  }

  try {
    const [updatedOrder, updatedAssignment] = await prisma.$transaction([
      prisma.order.update({ where: { id }, data: { status: nextStatus } }),
      prisma.courierAssignment.update({
        where: { orderId: id },
        data: {
          proofPhoto: parsed.data.proofPhoto,
          latitude: parsed.data.latitude,
          longitude: parsed.data.longitude,
          deliveredAt: nextStatus === "DELIVERED" ? new Date() : undefined
        }
      })
    ]);
    return NextResponse.json({ order: updatedOrder, assignment: updatedAssignment });
  } catch {
    return NextResponse.json({ error: "Буюртма ҳолатини сақлашда хатолик." }, { status: 500 });
  }
}
