import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-auth";

const schema = z.object({
  nameUz: z.string().trim().min(2).max(160),
  nameRu: z.string().max(160).default(""),
  nameEn: z.string().max(160).default(""),
  nameAr: z.string().max(160).default(""),
  price: z.number().finite().positive(),
  currency: z.enum(["UZS", "USD", "SAR"]).default("UZS"),
  sku: z.string().max(80).optional(),
  imageUrls: z.array(z.string().url()).max(8).default([])
});

export async function GET(request: Request) {
  const denied = await requireAdmin();
  if (denied) return denied;
  const products = await prisma.product.findMany({
    include: { images: { orderBy: { sortOrder: "asc" } } },
    orderBy: { createdAt: "desc" }
  });
  return NextResponse.json({ products });
}

export async function POST(request: Request) {
  const denied = await requireAdmin();
  if (denied) return denied;
  const body = await request.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid product data", details: parsed.error.flatten() }, { status: 400 });

  const d = parsed.data;
  try {
    const product = await prisma.product.create({
      data: {
        nameUz: d.nameUz, nameRu: d.nameRu, nameEn: d.nameEn, nameAr: d.nameAr,
        price: d.price, currency: d.currency, sku: d.sku || undefined,
        images: { create: d.imageUrls.map((url, sortOrder) => ({ url, sortOrder })) }
      },
      include: { images: true }
    });
    return NextResponse.json({ product }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not create product. Check database and unique SKU." }, { status: 409 });
  }
}
