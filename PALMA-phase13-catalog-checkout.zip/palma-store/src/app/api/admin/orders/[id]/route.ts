import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-auth";
import { orderStatusMessage } from "@/lib/notifications";

const schema = z.object({
  status: z.enum(["NEW", "CONFIRMED", "PREPARING", "SHIPPING", "DELIVERED", "CANCELLED"])
});

const allowed: Record<string, string[]> = {
  NEW: ["CONFIRMED", "CANCELLED"],
  CONFIRMED: ["PREPARING", "CANCELLED"],
  PREPARING: ["SHIPPING", "CANCELLED"],
  SHIPPING: ["DELIVERED"],
  DELIVERED: [],
  CANCELLED: []
};

async function notifyCustomer(telegramId: string, orderNumber: string, status: string, locale: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return;
  const labels: Record<string, string> = {
    NEW: "Янги", CONFIRMED: "Тасдиқланди", PREPARING: "Тайёрланмоқда",
    SHIPPING: "Йўлда", DELIVERED: "Етказилди", CANCELLED: "Бекор қилинди"
  };
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        chat_id: telegramId,
        text: orderStatusMessage(locale, orderNumber, status)
      })
    });
  } catch {
    // Order status is saved even if Telegram delivery fails.
  }
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const denied = await requireAdmin();
  if (denied) return denied;

  const { id } = await context.params;
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Статус нотўғри." }, { status: 400 });

  try {
    const current = await prisma.order.findUnique({
      where: { id },
      include: { user: { select: { telegramId: true, preferredLang: true } } }
    });
    if (!current) return NextResponse.json({ error: "Буюртма топилмади." }, { status: 404 });

    const next = parsed.data.status;
    if (!allowed[current.status].includes(next)) {
      return NextResponse.json({
        error: `Бу статусдан ${next} ҳолатига ўтиш мумкин эмас.`
      }, { status: 409 });
    }

    const updated = await prisma.order.update({
      where: { id },
      data: { status: next }
    });

    if (current.user.telegramId) {
      await notifyCustomer(current.user.telegramId, current.orderNumber, next, current.user.preferredLang);
    }

    return NextResponse.json({ order: updated });
  } catch {
    return NextResponse.json({ error: "Статусни янгилашда хатолик." }, { status: 500 });
  }
}
