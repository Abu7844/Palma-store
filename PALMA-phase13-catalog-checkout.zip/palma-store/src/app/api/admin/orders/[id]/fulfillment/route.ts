import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-auth";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin();
  if (auth) return auth;
  const { id } = await context.params;
  const order = await prisma.order.findUnique({
    where: { id },
    select: {
      id: true, orderNumber: true, country: true, city: true,
      fulfillments: { include: { warehouse: true }, orderBy: { createdAt: "asc" } }
    }
  });
  if (!order) return NextResponse.json({ error: "Буюртма топилмади" }, { status: 404 });
  return NextResponse.json({ order });
}
