import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-auth";

export async function GET(request: Request) {
  const denied = await requireAdmin();
  if (denied) return denied;

  try {
    const orders = await prisma.order.findMany({
      include: {
        user: { select: { name: true, phone: true, email: true, telegramId: true } },
        items: true
      },
      orderBy: { createdAt: "desc" },
      take: 200
    });
    return NextResponse.json({ orders });
  } catch {
    return NextResponse.json({ error: "Буюртмаларни юклаб бўлмади." }, { status: 503 });
  }
}
