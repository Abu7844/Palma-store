import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireRoles } from "@/lib/admin-auth";

export async function GET() {
  const access=await requireRoles(["OWNER","ADMIN","OPERATOR"]);
  if(access.response) return access.response;
  const reviews=await prisma.review.findMany({
    include:{product:{select:{nameUz:true}},user:{select:{name:true}},},
    orderBy:{createdAt:"desc"},take:200
  });
  return NextResponse.json({reviews});
}
export async function PATCH(request:Request) {
  const access=await requireRoles(["OWNER","ADMIN","OPERATOR"]);
  if(access.response) return access.response;
  const schema=z.object({id:z.string().min(1),isApproved:z.boolean()});
  const parsed=schema.safeParse(await request.json().catch(()=>null));
  if(!parsed.success) return NextResponse.json({error:"Маълумот нотўғри."},{status:400});
  const review=await prisma.review.update({where:{id:parsed.data.id},data:{isApproved:parsed.data.isApproved}});
  return NextResponse.json({review});
}
