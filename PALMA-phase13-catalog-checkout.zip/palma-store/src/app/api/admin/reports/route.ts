import { NextResponse } from "next/server";
import { requireRoles } from "@/lib/admin-auth";
import { prisma } from "@/lib/prisma";

function csvCell(value: unknown) {
  const s=String(value ?? "");
  return `"${s.replace(/"/g,'""')}"`;
}
export async function GET(request:Request) {
  const access=await requireRoles(["OWNER","ADMIN","ACCOUNTANT"]);
  if(access.response) return access.response;
  const url=new URL(request.url);
  const from=url.searchParams.get("from");
  const to=url.searchParams.get("to");
  const where:any={};
  if(from || to) where.createdAt={...(from?{gte:new Date(from)}:{}),...(to?{lte:new Date(to)}:{})};
  const orders=await prisma.order.findMany({
    where,include:{user:{select:{name:true,phone:true}},items:true},
    orderBy:{createdAt:"desc"},take:10000
  });
  const rows=[
    ["orderNumber","createdAt","customer","phone","status","paymentStatus","country","city","currency","subtotal","discount","shipping","total"],
    ...orders.map(o=>[o.orderNumber,o.createdAt.toISOString(),o.user.name,o.user.phone,o.status,o.paymentStatus,o.country,o.city,o.currency,o.subtotal,o.discount,o.shippingPrice,o.total])
  ];
  const csv="\uFEFF"+rows.map(row=>row.map(csvCell).join(",")).join("\r\n");
  return new NextResponse(csv,{headers:{
    "content-type":"text/csv; charset=utf-8",
    "content-disposition":'attachment; filename="palma-orders-report.csv"',
    "cache-control":"no-store"
  }});
}
