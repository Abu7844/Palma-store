import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireOwner } from "@/lib/admin-auth";

const roles = ["OWNER", "ADMIN", "OPERATOR", "COURIER", "ACCOUNTANT", "CUSTOMER"] as const;

export async function GET() {
  const denied = await requireOwner();
  if (denied) return denied;
  const users = await prisma.user.findMany({
    where: { role: { in: ["OWNER", "ADMIN", "OPERATOR", "COURIER", "ACCOUNTANT"] } },
    select: { id: true, name: true, email: true, phone: true, telegramId: true, role: true, isActive: true, createdAt: true },
    orderBy: { createdAt: "asc" }
  });
  return NextResponse.json({ users });
}

export async function PATCH(req: NextRequest) {
  const denied = await requireOwner();
  if (denied) return denied;
  const body = await req.json().catch(() => null);
  const userId = String(body?.userId ?? "");
  const role = String(body?.role ?? "");
  const isActive = body?.isActive;
  if (!userId || (!roles.includes(role as typeof roles[number]) && typeof isActive !== "boolean")) {
    return NextResponse.json({ error: "Ходим ID ва янги роль/ҳолат керак." }, { status: 400 });
  }
  const data: { role?: typeof roles[number]; isActive?: boolean } = {};
  if (roles.includes(role as typeof roles[number])) data.role = role as typeof roles[number];
  if (typeof isActive === "boolean") data.isActive = isActive;

  const target = await prisma.user.findUnique({ where: { id: userId } });
  if (!target) return NextResponse.json({ error: "Фойдаланувчи топилмади." }, { status: 404 });
  if (target.role === "OWNER" && (data.role && data.role !== "OWNER" || data.isActive === false)) {
    const owners = await prisma.user.count({ where: { role: "OWNER", isActive: true } });
    if (owners <= 1) return NextResponse.json({ error: "Охирги фаол эгасини ўчириш ёки ролини тушириш мумкин эмас." }, { status: 409 });
  }
  const user = await prisma.user.update({
    where: { id: userId }, data,
    select: { id: true, name: true, role: true, isActive: true }
  });
  return NextResponse.json({ user });
}
