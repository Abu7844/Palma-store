import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-auth";

const schema = z.object({
  orderId: z.string().min(1),
  courierId: z.string().min(1)
});

export async function GET(request: Request) {
  const denied = await requireAdmin();
  if (denied) return denied;

  const assignments = await prisma.courierAssignment.findMany({
    include: {
      // IDs are returned for admin assignment management.
    },
    orderBy: { assignedAt: "desc" },
    take: 200
  });
  return NextResponse.json({ assignments });
}

export async function POST(request: Request) {
  const denied = await requireAdmin();
  if (denied) return denied;

  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Буюртма ва курьер танланиши керак." }, { status: 400 });
  }

  const { orderId, courierId } = parsed.data;
  try {
    const [order, courier] = await Promise.all([
      prisma.order.findUnique({ where: { id: orderId } }),
      prisma.user.findUnique({ where: { id: courierId }, select: { id: true, role: true, isActive: true } })
    ]);

    if (!order) return NextResponse.json({ error: "Буюртма топилмади." }, { status: 404 });
    if (!courier || courier.role !== "COURIER" || !courier.isActive) {
      return NextResponse.json({ error: "Фаол курьер аккаунти топилмади." }, { status: 400 });
    }
    if (["DELIVERED", "CANCELLED"].includes(order.status)) {
      return NextResponse.json({ error: "Якунланган буюртмага курьер бириктириб бўлмайди." }, { status: 409 });
    }

    const assignment = await prisma.courierAssignment.upsert({
      where: { orderId },
      update: { courierId, assignedAt: new Date(), deliveredAt: null, proofPhoto: null },
      create: { orderId, courierId }
    });

    return NextResponse.json({ assignment }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Курьерни бириктиришда хатолик." }, { status: 500 });
  }
}
