import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRoles } from "@/lib/admin-auth";

export async function GET() {
  const access = await requireRoles(["OWNER", "ADMIN", "ACCOUNTANT"]);
  if (access.response) return access.response;
  const payments = await prisma.paymentTransaction.findMany({
    include: { order: { select: { orderNumber: true, paymentStatus: true, total: true, currency: true } } },
    orderBy: { createdAt: "desc" },
    take: 250
  });
  return NextResponse.json({ payments });
}
