import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-auth";

export async function POST(req: NextRequest) {
  const auth = await requireAdmin();
  if (auth) return auth;
  const body = await req.json();
  const fromWarehouseId = String(body.fromWarehouseId ?? "");
  const toWarehouseId = String(body.toWarehouseId ?? "");
  const productId = String(body.productId ?? "");
  const quantity = Number(body.quantity);
  if (!fromWarehouseId || !toWarehouseId || fromWarehouseId === toWarehouseId ||
      !productId || !Number.isInteger(quantity) || quantity <= 0) {
    return NextResponse.json({ error: "Омборлар, маҳсулот ва миқдорни тўғри киритинг" }, { status: 400 });
  }
  try {
    const result = await prisma.$transaction(async (tx) => {
      const from = await tx.warehouseStock.findUnique({
        where: { warehouseId_productId: { warehouseId: fromWarehouseId, productId } },
      });
      if (!from || from.quantity < quantity) throw new Error("INSUFFICIENT");
      await tx.warehouseStock.update({
        where: { warehouseId_productId: { warehouseId: fromWarehouseId, productId } },
        data: { quantity: { decrement: quantity } },
      });
      const to = await tx.warehouseStock.upsert({
        where: { warehouseId_productId: { warehouseId: toWarehouseId, productId } },
        create: { warehouseId: toWarehouseId, productId, quantity },
        update: { quantity: { increment: quantity } },
      });
      await tx.stockMovement.createMany({ data: [
        { warehouseId: fromWarehouseId, productId, quantity: -quantity, type: "TRANSFER", note: `Кўчириш → ${toWarehouseId}` },
        { warehouseId: toWarehouseId, productId, quantity, type: "TRANSFER", note: `Кўчириш ← ${fromWarehouseId}` },
      ]});
      await tx.auditLog.create({
        data: { action: "INVENTORY_TRANSFER", entity: "WarehouseStock", entityId: productId,
          metadata: { fromWarehouseId, toWarehouseId, quantity } },
      });
      return { fromQuantity: from.quantity - quantity, to };
    });
    return NextResponse.json(result);
  } catch (e) {
    const insufficient = e instanceof Error && e.message === "INSUFFICIENT";
    return NextResponse.json({ error: insufficient ? "Жўнатувчи омборда етарли қолдиқ йўқ" : "Кўчириш амалга ошмади" }, { status: insufficient ? 409 : 500 });
  }
}
