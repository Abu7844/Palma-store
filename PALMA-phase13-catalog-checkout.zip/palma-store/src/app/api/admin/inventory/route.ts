import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-auth";

export async function GET() {
  const auth = await requireAdmin();
  if (auth) return auth;
  const stocks = await prisma.warehouseStock.findMany({
    include: { warehouse: true, product: true },
    orderBy: [{ warehouse: { country: "asc" } }, { warehouse: { city: "asc" } }],
  });
  return NextResponse.json({
    stocks,
    lowStock: stocks.filter((s) => s.quantity <= (s.lowStockThreshold ?? 5)),
  });
}

export async function POST(req: NextRequest) {
  const auth = await requireAdmin();
  if (auth) return auth;
  const body = await req.json();
  const warehouseId = String(body.warehouseId ?? "");
  const productId = String(body.productId ?? "");
  const delta = Number(body.delta);
  const threshold = body.lowStockThreshold == null ? undefined : Number(body.lowStockThreshold);
  if (!warehouseId || !productId || !Number.isInteger(delta) || delta === 0 ||
      (threshold !== undefined && (!Number.isInteger(threshold) || threshold < 0))) {
    return NextResponse.json({ error: "Омбор, маҳсулот ва бутун сонли ўзгариш киритинг" }, { status: 400 });
  }

  try {
    const result = await prisma.$transaction(async (tx) => {
      const current = await tx.warehouseStock.findUnique({
        where: { warehouseId_productId: { warehouseId, productId } },
      });
      const nextQty = (current?.quantity ?? 0) + delta;
      if (nextQty < 0) throw new Error("STOCK_NEGATIVE");
      const stock = await tx.warehouseStock.upsert({
        where: { warehouseId_productId: { warehouseId, productId } },
        create: { warehouseId, productId, quantity: nextQty, ...(threshold === undefined ? {} : { lowStockThreshold: threshold }) },
        update: { quantity: nextQty, ...(threshold === undefined ? {} : { lowStockThreshold: threshold }) },
      });
      await tx.stockMovement.create({
        data: {
          warehouseId, productId, quantity: delta,
          type: delta > 0 ? "IN" : "OUT",
          note: String(body.note ?? "Админ панели орқали қолдиқ ўзгартирилди").slice(0, 500),
        },
      });
      await tx.auditLog.create({
        data: {
          action: "INVENTORY_ADJUSTMENT",
          entity: "WarehouseStock",
          entityId: `${warehouseId}:${productId}`,
          metadata: { before: current?.quantity ?? 0, after: nextQty, delta },
        },
      });
      return stock;
    });

    if (result.quantity <= (result.lowStockThreshold ?? 5) && process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_ADMIN_CHAT_ID) {
      const message = `⚠️ PALMA: омбордаги қолдиқ кам\nМаҳсулот ID: ${productId}\nОмбор ID: ${warehouseId}\nҚолдиқ: ${result.quantity}`;
      fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ chat_id: process.env.TELEGRAM_ADMIN_CHAT_ID, text: message }),
      }).catch(() => {});
    }
    return NextResponse.json({ stock: result });
  } catch (e) {
    const message = e instanceof Error ? e.message : "UNKNOWN";
    return NextResponse.json({ error: message === "STOCK_NEGATIVE" ? "Омбор қолдиғи манфий бўлиши мумкин эмас" : "Қолдиқни сақлаб бўлмади" }, { status: message === "STOCK_NEGATIVE" ? 409 : 500 });
  }
}
