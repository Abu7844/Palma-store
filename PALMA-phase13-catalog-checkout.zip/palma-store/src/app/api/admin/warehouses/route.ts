import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-auth";

export async function GET() {
  const auth = await requireAdmin();
  if (auth) return auth;
  const warehouses = await prisma.warehouse.findMany({
    include: { stocks: { include: { product: true } } },
    orderBy: [{ country: "asc" }, { city: "asc" }, { name: "asc" }],
  });
  return NextResponse.json({ warehouses });
}

export async function POST(req: NextRequest) {
  const auth = await requireAdmin();
  if (auth) return auth;
  const body = await req.json();
  const name = String(body.name ?? "").trim();
  const country = String(body.country ?? "").trim();
  const city = String(body.city ?? "").trim();
  if (!name || !country || !city) {
    return NextResponse.json({ error: "name, country ва city мажбурий" }, { status: 400 });
  }
  const warehouse = await prisma.warehouse.create({
    data: {
      name, country, city,
      address: body.address ? String(body.address).trim() : null,
      latitude: body.latitude == null ? null : Number(body.latitude),
      longitude: body.longitude == null ? null : Number(body.longitude),
      isActive: true,
    },
  });
  return NextResponse.json({ warehouse }, { status: 201 });
}
