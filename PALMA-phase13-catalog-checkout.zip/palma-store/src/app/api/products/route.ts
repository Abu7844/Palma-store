import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const products = await prisma.product.findMany({
      where: { isActive: true },
      include: { images: { orderBy: { sortOrder: "asc" } }, stockItems: { select: { quantity: true } } },
      orderBy: { createdAt: "desc" }
    });
    return NextResponse.json({ products });
  } catch {
    return NextResponse.json({ error: "Catalogue unavailable. Configure database and run migrations." }, { status: 503 });
  }
}
