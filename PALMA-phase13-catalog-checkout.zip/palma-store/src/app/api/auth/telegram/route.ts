import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { setSessionCookie } from "@/lib/session";
import { verifyTelegramInitData } from "@/lib/telegram";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null) as { initData?: string } | null;
  if (!body?.initData || typeof body.initData !== "string") {
    return NextResponse.json({ error: "Telegram initData керак." }, { status: 400 });
  }

  const telegramUser = verifyTelegramInitData(body.initData);
  if (!telegramUser) {
    return NextResponse.json({ error: "Telegram авторизацияси текширувдан ўтмади." }, { status: 401 });
  }

  try {
    const lang = ["uz", "ru", "en", "ar"].includes(telegramUser.language_code || "")
      ? telegramUser.language_code!
      : "uz";
    const user = await prisma.user.upsert({
      where: { telegramId: String(telegramUser.id) },
      update: { name: telegramUser.first_name, preferredLang: lang },
      create: {
        telegramId: String(telegramUser.id),
        name: telegramUser.first_name,
        preferredLang: lang
      }
    });

    await setSessionCookie(user.id);
    return NextResponse.json({
      ok: true,
      user: {
        id: user.id,
        name: user.name,
        preferredLang: user.preferredLang,
        role: user.role
      }
    });
  } catch {
    return NextResponse.json({ error: "Авторизация серверда якунланмади." }, { status: 500 });
  }
}
