import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { verifyPaymentWebhook } from "@/lib/payments/webhook";

const eventSchema = z.object({
  eventId: z.string().min(8).max(200),
  transactionId: z.string().min(1),
  provider: z.enum(["PAYME", "CLICK", "UZCARD", "VISA"]),
  status: z.enum(["PAID", "FAILED"]),
  amount: z.number().finite().positive(),
  currency: z.string().length(3)
});

export async function POST(request: Request) {
  const raw = await request.text();
  if (!verifyPaymentWebhook(raw, request.headers.get("x-palma-payment-signature"))) {
    return NextResponse.json({ error: "Имзо нотўғри." }, { status: 401 });
  }
  let json: unknown;
  try { json = JSON.parse(raw); } catch {
    return NextResponse.json({ error: "JSON нотўғри." }, { status: 400 });
  }
  const parsed = eventSchema.safeParse(json);
  if (!parsed.success) return NextResponse.json({ error: "Webhook маълумоти нотўғри." }, { status: 400 });
  const event = parsed.data;

  try {
    const result = await prisma.$transaction(async tx => {
      const payment = await tx.paymentTransaction.findUnique({ where: { id: event.transactionId } });
      if (!payment) throw new Error("PAYMENT_NOT_FOUND");
      if (payment.provider !== event.provider) throw new Error("PROVIDER_MISMATCH");
      if (payment.currency !== event.currency || Math.abs(Number(payment.amount) - event.amount) > 0.0001) {
        throw new Error("AMOUNT_MISMATCH");
      }
      if (payment.eventId === event.eventId) return { duplicate: true, status: payment.status };
      if (payment.status === "PAID" && event.status !== "PAID") throw new Error("FINAL_STATE");
      if (payment.status === "FAILED" && event.status === "PAID") throw new Error("FINAL_STATE");

      await tx.paymentTransaction.update({
        where: { id: payment.id },
        data: { status: event.status, eventId: event.eventId }
      });
      await tx.order.update({
        where: { id: payment.orderId },
        data: { paymentStatus: event.status }
      });
      return { duplicate: false, status: event.status };
    });
    return NextResponse.json({ ok: true, ...result });
  } catch (error) {
    const code = error instanceof Error ? error.message : "";
    const status = code === "PAYMENT_NOT_FOUND" ? 404 : code === "FINAL_STATE" ? 409 : 400;
    const messages: Record<string,string> = {
      PAYMENT_NOT_FOUND: "Транзакция топилмади.",
      PROVIDER_MISMATCH: "Провайдер мос эмас.",
      AMOUNT_MISMATCH: "Сумма ёки валюта мос эмас.",
      FINAL_STATE: "Якунланган тўлов ҳолатини ўзгартириб бўлмайди."
    };
    return NextResponse.json({ error: messages[code] || "Webhook қабул қилинмади." }, { status });
  }
}
