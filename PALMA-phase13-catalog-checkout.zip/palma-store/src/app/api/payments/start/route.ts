import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { getPaymentAdapter } from "@/lib/payments";
import type { OnlineProvider } from "@/lib/payments/types";

const schema = z.object({
  orderId: z.string().min(1),
  provider: z.enum(["PAYME", "CLICK", "UZCARD", "VISA"])
});

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Аввал тизимга киринг." }, { status: 401 });
  const body = await request.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Тўлов маълумотлари нотўғри." }, { status: 400 });

  const order = await prisma.order.findFirst({
    where: { id: parsed.data.orderId, userId: user.id },
    select: { id: true, orderNumber: true, total: true, currency: true, paymentStatus: true }
  });
  if (!order) return NextResponse.json({ error: "Буюртма топилмади." }, { status: 404 });
  if (order.paymentStatus === "PAID") return NextResponse.json({ error: "Буюртма аллақачон тўланган." }, { status: 409 });

  const adapter = getPaymentAdapter(parsed.data.provider as OnlineProvider);
  const result = await adapter.start({
    orderId: order.id,
    orderNumber: order.orderNumber,
    amountMinor: Math.round(Number(order.total) * 100),
    currency: order.currency,
    returnUrl: `${process.env.NEXTAUTH_URL || new URL(request.url).origin}/orders/${order.id}`
  });

  const transaction = await prisma.paymentTransaction.create({
    data: {
      orderId: order.id,
      provider: parsed.data.provider,
      amount: order.total,
      currency: order.currency,
      status: result.configured ? "PENDING" : "NOT_CONFIGURED"
    }
  });

  if (!result.configured) {
    return NextResponse.json({
      ok: false,
      status: "NOT_CONFIGURED",
      transactionId: transaction.id,
      message: result.reason,
      orderNumber: order.orderNumber
    }, { status: 501 });
  }
  return NextResponse.json({ ok: true, transactionId: transaction.id, checkoutUrl: result.checkoutUrl });
}
