"use client";
import { useEffect, useState } from "react";

type CourierOrder = {
  assignment: { id: string; proofPhoto: string | null };
  order: {
    id: string; orderNumber: string; status: string; country: string; city: string;
    fullAddress: string; postalCode: string | null; total: string | number; currency: string;
    user: { name: string | null; phone: string | null };
    items: { id: string; productName: string; quantity: number }[];
  };
};

export function CourierDashboard() {
  const [orders, setOrders] = useState<CourierOrder[]>([]);
  const [message, setMessage] = useState("Буюртмалар юкланмоқда...");
  const [busy, setBusy] = useState(false);
  const [proof, setProof] = useState<Record<string, string>>({});

  async function load() {
    setBusy(true);
    try {
      const response = await fetch("/api/courier/orders");
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Буюртмаларни олиб бўлмади");
      setOrders(data.orders);
      setMessage(data.orders.length ? "" : "Сизга ҳозирча буюртма бириктирилмаган.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Хатолик юз берди");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => { void load(); }, []);

  async function update(orderId: string, status: "SHIPPING" | "DELIVERED") {
    setBusy(true);
    try {
      const payload: { status: string; proofPhoto?: string } = { status };
      if (status === "DELIVERED") {
        const url = proof[orderId]?.trim();
        if (!url) throw new Error("Етказилганини тасдиқлаш учун фото URL киритинг.");
        payload.proofPhoto = url;
      }
      const response = await fetch(`/api/courier/orders/${orderId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Статус ўзгартирилмади");
      setMessage("Буюртма ҳолати янгиланди.");
      await load();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Хатолик юз берди");
      setBusy(false);
    }
  }

  return <section className="courierDash">
    <div className="adminTitle"><div><h2>Менинг буюртмаларим</h2><p>Сизга бириктирилган етказиб беришлар</p></div><button className="filter" onClick={load} disabled={busy}>Янгилаш</button></div>
    {message && <div className="adminMessage">{message}</div>}
    <div className="courierOrders">{orders.map(({order})=><article className="orderCard" key={order.id}>
      <div className="orderTop"><div><b>{order.orderNumber}</b><small>{order.country}, {order.city}</small></div><strong>{order.status}</strong></div>
      <div className="orderCustomer">{order.user.name || "Мижоз"} · {order.user.phone || "Телефон йўқ"}</div>
      <div className="orderAddress">{order.fullAddress}{order.postalCode ? `, ${order.postalCode}` : ""}</div>
      <ul>{order.items.map(item=><li key={item.id}>{item.productName} × {item.quantity}</li>)}</ul>
      <div className="courierActions">
        {order.status !== "SHIPPING" && order.status !== "DELIVERED" && <button className="checkoutButton" disabled={busy} onClick={()=>update(order.id,"SHIPPING")}>Етказишга чиқдим</button>}
        {order.status === "SHIPPING" && <><input placeholder="Етказилганлик фото URL" value={proof[order.id] || ""} onChange={e=>setProof({...proof,[order.id]:e.target.value})}/><button className="checkoutButton" disabled={busy} onClick={()=>update(order.id,"DELIVERED")}>Етказилди</button></>}
        {order.status === "DELIVERED" && <span className="pill">Етказилди</span>}
        <a className="filter" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${order.fullAddress}, ${order.city}, ${order.country}`)}`} target="_blank" rel="noreferrer">Харитада очиш ↗</a>
        {order.user.phone && <a className="filter" href={`tel:${order.user.phone}`}>Қўнғироқ</a>}
      </div>
    </article>)}</div>
  </section>;
}
