"use client";
import { useState } from "react";

type Product = { id: string; nameUz: string; price: string | number; currency: string; isActive: boolean };

export function AdminProducts() {
  const [key, setKey] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ nameUz:"", nameRu:"", nameEn:"", nameAr:"", price:"", currency:"UZS", sku:"", imageUrls:"" });

  async function load() {
    setBusy(true); setMessage("");
    try {
      const r = await fetch("/api/admin/products", { headers: { "x-admin-key": key } });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Маълумотни олиб бўлмади");
      setProducts(d.products); setUnlocked(true); setMessage("Маҳсулотлар юкланди.");
    } catch (e) {
      setUnlocked(false); setMessage(e instanceof Error ? e.message : "Хатолик");
    } finally { setBusy(false); }
  }

  async function create(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const r = await fetch("/api/admin/products", {
        method:"POST", headers:{"content-type":"application/json","x-admin-key":key},
        body:JSON.stringify({
          nameUz:form.nameUz, nameRu:form.nameRu, nameEn:form.nameEn, nameAr:form.nameAr,
          price:Number(form.price), currency:form.currency, sku:form.sku || undefined,
          imageUrls:form.imageUrls.split("\\n").map(s=>s.trim()).filter(Boolean)
        })
      });
      const d=await r.json(); if(!r.ok) throw new Error(d.error || "Сақланмади");
      setForm({nameUz:"",nameRu:"",nameEn:"",nameAr:"",price:"",currency:"UZS",sku:"",imageUrls:""});
      setMessage("Маҳсулот сақланди."); await load();
    } catch(e) { setMessage(e instanceof Error ? e.message : "Хатолик"); setBusy(false); }
  }

  async function archive(id:string) {
    if(!confirm("Маҳсулотни каталогдан яширишни тасдиқлайсизми?")) return;
    setBusy(true);
    try {
      const r=await fetch(`/api/admin/products/${id}`,{method:"DELETE",headers:{"x-admin-key":key}});
      const d=await r.json(); if(!r.ok) throw new Error(d.error || "Ўчириб бўлмади");
      await load();
    } catch(e) { setMessage(e instanceof Error ? e.message : "Хатолик"); setBusy(false); }
  }

  return <div className="adminWrap">
    {!unlocked ? <section className="adminGate">
      <h2>Админ кириши</h2><p>Сервердаги ADMIN_ACCESS_KEY ни киритинг. Калит браузерда сақланмайди.</p>
      <input type="password" value={key} onChange={e=>setKey(e.target.value)} placeholder="Админ калити"/>
      <button className="checkoutButton" disabled={!key || busy} onClick={load}>{busy?"Текширилмоқда...":"Кириш"}</button>
      {message && <p className="adminMessage">{message}</p>}
    </section> : <>
      <section className="adminSection">
        <div className="adminTitle"><div><h2>Янги маҳсулот</h2><p>Маҳсулот маълумотларини киритинг</p></div><button className="filter" onClick={load} disabled={busy}>Янгилаш</button></div>
        <form className="adminForm" onSubmit={create}>
          <label>Номи (ўзбекча) *<input required value={form.nameUz} onChange={e=>setForm({...form,nameUz:e.target.value})}/></label>
          <div className="adminTwo"><label>Русча номи<input value={form.nameRu} onChange={e=>setForm({...form,nameRu:e.target.value})}/></label><label>Инглизча номи<input value={form.nameEn} onChange={e=>setForm({...form,nameEn:e.target.value})}/></label></div>
          <label>Арабча номи<input value={form.nameAr} onChange={e=>setForm({...form,nameAr:e.target.value})}/></label>
          <div className="adminTwo"><label>Нарх *<input required type="number" min="0.01" step="0.01" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></label><label>Валюта<select value={form.currency} onChange={e=>setForm({...form,currency:e.target.value})}><option>UZS</option><option>USD</option><option>SAR</option></select></label></div>
          <label>SKU<input value={form.sku} onChange={e=>setForm({...form,sku:e.target.value})}/></label>
          <label>Расм URL манзиллари (ҳар бири янги қаторда)<textarea rows={3} value={form.imageUrls} onChange={e=>setForm({...form,imageUrls:e.target.value})}/></label>
          <button className="checkoutButton" disabled={busy}>{busy?"Сақланмоқда...":"Маҳсулотни сақлаш"}</button>
        </form>
        {message && <p className="adminMessage">{message}</p>}
      </section>
      <section className="adminSection">
        <div className="adminTitle"><div><h2>Маҳсулотлар</h2><p>Базада: {products.length} та</p></div></div>
        <div className="adminList">{products.map(p=><div className="adminProduct" key={p.id}><div><b>{p.nameUz}</b><small>{Number(p.price).toLocaleString()} {p.currency} · {p.isActive?"Фаол":"Яширилган"}</small></div><button className="filter" disabled={busy || !p.isActive} onClick={()=>archive(p.id)}>Яшириш</button></div>)}</div>
      </section>
    </>}
  </div>;
}
