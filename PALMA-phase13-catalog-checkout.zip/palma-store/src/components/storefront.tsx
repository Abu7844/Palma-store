"use client";

import { useEffect, useMemo, useState } from "react";

type Product = {
  id: string;
  nameUz: string; nameRu: string; nameEn: string; nameAr: string;
  descriptionUz: string; descriptionRu: string; descriptionEn: string; descriptionAr: string;
  price: string | number; currency: string; images: { id: string; url: string }[];
  stockItems?: { quantity: number }[];
};

type Cart = Record<string, number>;
const money = (value: number, currency: string) =>
  new Intl.NumberFormat("uz-UZ", { maximumFractionDigits: 0 }).format(value) + " " + currency;

export function Storefront() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [cart, setCart] = useState<Cart>({});
  const [search, setSearch] = useState("");
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [form, setForm] = useState({
    name: "", phone: "", email: "", country: "", city: "",
    fullAddress: "", postalCode: "", comment: "", promoCode: ""
  });

  useEffect(() => {
    fetch("/api/products")
      .then(async r => {
        const data = await r.json();
        if (!r.ok) throw new Error(data.error || "Каталогни юклаб бўлмади");
        setProducts(data.products || []);
      })
      .catch(e => setLoadError(e.message || "Каталогни юклаб бўлмади"))
      .finally(() => setLoading(false));
  }, []);

  const visible = useMemo(() => products.filter(p =>
    `${p.nameUz} ${p.nameRu} ${p.nameEn} ${p.descriptionUz}`.toLowerCase().includes(search.toLowerCase())
  ), [products, search]);

  const cartProducts = products.filter(p => (cart[p.id] || 0) > 0);
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const currency = cartProducts[0]?.currency || "UZS";
  const mixedCurrencies = cartProducts.some(p => p.currency !== currency);
  const subtotal = cartProducts.reduce((sum, p) => sum + Number(p.price) * cart[p.id], 0);
  const add = (id: string) => setCart(old => ({ ...old, [id]: (old[id] || 0) + 1 }));
  const remove = (id: string) => setCart(old => {
    const next = { ...old };
    if ((next[id] || 0) <= 1) delete next[id]; else next[id]--;
    return next;
  });
  const updateForm = (key: keyof typeof form, value: string) => setForm(old => ({ ...old, [key]: value }));

  async function submitOrder(e: React.FormEvent) {
    e.preventDefault();
    setMessage("");
    if (!cartProducts.length || mixedCurrencies) {
      setMessage("Саватдаги маҳсулотлар валютаси бир хил бўлиши керак.");
      return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          ...form, currency, paymentMethod: "CASH",
          items: cartProducts.map(p => ({ productId: p.id, quantity: cart[p.id] }))
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Буюртма қабул қилинмади");
      setOrderNumber(data.order.orderNumber);
      setCart({});
      setCheckoutOpen(false);
      setCartOpen(false);
      setMessage("");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Хатолик юз берди");
    } finally {
      setBusy(false);
    }
  }

  return <div>
    <header className="topbar"><div className="shell topbarInner">
      <a className="brand" href="/">PALMA<span>.</span></a>
      <nav className="nav"><a href="#catalog">Каталог</a><a href="/orders">Буюртмаларим</a><a href="/support">Ёрдам</a></nav>
      <div className="headActions"><a className="pill" href="/account">Кириш</a><button className="cartButton" onClick={() => setCartOpen(true)}>Сават <b>{count}</b></button></div>
    </div></header>

    <div className="shell">
      <section className="hero"><div><div className="heroTag">PALMA INTERNATIONAL STORE</div>
        <h1>Сифатли танлов.<br/>Янги тажриба.</h1>
        <p>PALMA дўконига хуш келибсиз. Ўзингизга мос маҳсулотларни танланг ва буюртмангизни қулай расмийлаштиринг.</p>
        <a className="heroCta" href="#catalog">Каталогни кўриш <span>↗</span></a>
      </div><div className="heroMark">P</div></section>

      <section className="trustRow">
        <div><strong>4 тил</strong><span>UZ · RU · EN · AR</span></div>
        <div><strong>Халқаро етказиш</strong><span>Мамлакат ва шаҳар бўйича</span></div>
        <div><strong>Қулай буюртма</strong><span>Нақд тўлов ҳозирча фаол</span></div>
      </section>

      <section id="catalog">
        <div className="sectionHead"><div><div className="eyebrow">PALMA COLLECTION</div><h2>Маҳсулотлар каталоги</h2></div><span className="muted">{visible.length} та маҳсулот</span></div>
        <div className="catalogTools">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Маҳсулот қидириш..." aria-label="Маҳсулот қидириш"/>
        </div>
        {loading && <div className="emptyState">Маҳсулотлар юкланмоқда...</div>}
        {!loading && loadError && <div className="emptyState">{loadError}. База ва миграцияларни текширинг.</div>}
        {!loading && !loadError && visible.length === 0 && <div className="emptyState">Ҳозирча каталогда маҳсулот йўқ. Админ панелдан маҳсулот киритинг.</div>}
        <div className="cards">{visible.map(p => {
          const stock = p.stockItems?.reduce((n, s) => n + s.quantity, 0);
          const image = p.images?.[0]?.url;
          return <article className="product" key={p.id}>
            <div className="productVisual">
              {image ? <img src={image} alt={p.nameUz} className="productPhoto"/> : <><div className="bottle"><i></i></div><span className="imageHint">PALMA</span></>}
            </div>
            <div className="productInfo"><h3>{p.nameUz}</h3><div className="productSub">{p.descriptionUz || "PALMA маҳсулоти"}</div>
              <div className="productBottom"><span className="price">{money(Number(p.price), p.currency)}</span>
                <button className="addButton" onClick={() => add(p.id)} aria-label={`${p.nameUz} саватга қўшиш`} disabled={stock !== undefined && stock <= 0}>+</button></div>
              {stock !== undefined && <small className="stockHint">{stock > 0 ? `Омборда: ${stock} та` : "Ҳозирча қолмаган"}</small>}
            </div>
          </article>;
        })}</div>
      </section>
      <footer className="footer"><div className="brand">PALMA<span>.</span></div><p>Сифатли танлов. Янги тажриба.</p><span>© {new Date().getFullYear()} PALMA</span></footer>
    </div>

    {message && <div className="toastError" role="alert">{message}<button onClick={() => setMessage("")}>✕</button></div>}
    {orderNumber && <div className="successOverlay"><div className="successCard"><div className="successMark">✓</div><h2>Буюртмангиз қабул қилинди!</h2><p>Буюртма рақами:</p><strong>{orderNumber}</strong><button className="checkoutButton" onClick={() => setOrderNumber("")}>Давом этиш</button></div></div>}

    {cartOpen && <div className="overlay" onClick={() => setCartOpen(false)}><aside className="cartPanel" onClick={e => e.stopPropagation()}>
      <div className="cartHead"><h2>Сизнинг саватингиз</h2><button onClick={() => setCartOpen(false)}>✕</button></div>
      {cartProducts.length === 0 ? <div className="emptyState">Сават ҳозирча бўш.</div> : <div className="cartItems">{cartProducts.map(p => <div className="cartItem" key={p.id}><div><b>{p.nameUz}</b><small>{money(Number(p.price), p.currency)}</small></div><div className="quantity"><button onClick={() => remove(p.id)}>−</button><b>{cart[p.id]}</b><button onClick={() => add(p.id)}>+</button></div></div>)}</div>}
      {mixedCurrencies && <div className="formError">Бир буюртмада фақат битта валютадаги маҳсулотлар бўлиши мумкин.</div>}
      <div className="cartTotal"><span>Жами</span><strong>{money(subtotal, currency)}</strong></div>
      <button className="checkoutButton" disabled={cartProducts.length === 0 || mixedCurrencies} onClick={() => { setCartOpen(false); setCheckoutOpen(true); }}>Буюртмани расмийлаштириш</button>
    </aside></div>}

    {checkoutOpen && <div className="overlay" onClick={() => !busy && setCheckoutOpen(false)}><section className="checkoutPanel" onClick={e => e.stopPropagation()}>
      <div className="cartHead"><h2>Буюртма маълумотлари</h2><button onClick={() => setCheckoutOpen(false)} disabled={busy}>✕</button></div>
      <p className="muted">Тўлов: товарни қабул қилганда нақд пул билан.</p>
      <form className="checkoutForm" onSubmit={submitOrder}>
        <label>Исмингиз *<input required minLength={2} value={form.name} onChange={e => updateForm("name", e.target.value)} /></label>
        <label>Телефон рақам *<input required minLength={7} value={form.phone} onChange={e => updateForm("phone", e.target.value)} placeholder="+998..." /></label>
        <label>Email<input type="email" value={form.email} onChange={e => updateForm("email", e.target.value)} /></label>
        <div className="checkoutTwo"><label>Мамлакат *<input required value={form.country} onChange={e => updateForm("country", e.target.value)} /></label><label>Шаҳар *<input required value={form.city} onChange={e => updateForm("city", e.target.value)} /></label></div>
        <label>Тўлиқ манзил *<textarea required minLength={5} value={form.fullAddress} onChange={e => updateForm("fullAddress", e.target.value)} /></label>
        <label>Почта индекси<input value={form.postalCode} onChange={e => updateForm("postalCode", e.target.value)} /></label>
        <label>Промокод<input value={form.promoCode} onChange={e => updateForm("promoCode", e.target.value)} /></label>
        <label>Изоҳ<textarea value={form.comment} onChange={e => updateForm("comment", e.target.value)} /></label>
        <div className="cartTotal"><span>Маҳсулотлар жами</span><strong>{money(subtotal, currency)}</strong></div>
        {message && <div className="formError">{message}</div>}
        <button className="checkoutButton" type="submit" disabled={busy}>{busy ? "Юборилмоқда..." : "Буюртмани тасдиқлаш"}</button>
      </form>
    </section></div>}
  </div>;
}
