"use client";
import { useState } from "react";

type Order = {
  id: string;
  orderNumber: string;
  status: string;
  currency: string;
  total: string | number;
  country: string;
  city: string;
  fullAddress: string;
  createdAt: string;
  user: { name: string | null; phone: string | null; email: string | null };
  items: { id: string; productName: string; quantity: number; unitPrice: string | number }[];
};

const statuses = [
  ["NEW", "Янги"], ["CONFIRMED", "Тасдиқланди"], ["PREPARING", "Тайёрланмоқда"],
  ["SHIPPING", "Йўлда"], ["DELIVERED", "Етказилди"], ["CANCELLED", "Бекор қилинди"]
];

export function AdminOrders() {
  const [key, setKey] = useState("");
  const [ready, setReady] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    setBusy(true); setMessage("");
    try {
      const r = await fetch("/api/admin/orders", { headers: { "x-admin-key": key } });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Буюртмаларни юклаб бўлмади");
      setOrders(d.orders); setReady(true); setMessage("Буюртмалар янгиланди.");
    } catch (e) {
      setReady(false); setMessage(e instanceof Error ? e.message : "Хатолик");
    } finally { setBusy(false); }
  }

  async function changeStatus(id: string, status: string) {
    setBusy(true); setMessage("");
    try {
      const r = await fetch(`/api/admin/orders/${id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json", "x-admin-key": key },
        body: JSON.stringify({ status })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Статус ўзгармади");
      setMessage("Буюртма ҳолати ўзгартирилди.");
      await load();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Хатолик");
      setBusy(false);
    }
  }

  if (!ready) return <section className="adminGate">
    <h2>Буюртмаларни бошқариш</h2>
    <p>Админ калитини киритинг.</p>
    <input type="password" value={key} onChange={e=>setKey(e.target.value)} placeholder="Админ калити"/>
    <button className="checkoutButton" disabled={!key || busy} onClick={load}>{busy?"Юкланмоқда...":"Буюртмаларни очиш"}</button>
    {message && <p className="adminMessage">{message}</p>}
  </section>;

  return <section className="adminSection orderAdmin">
    <div className="adminTitle"><div><h2>Буюртмалар</h2><p>Охирги {orders.length} та буюртма</p></div><button className="filter" onClick={load} disabled={busy}>Янгилаш</button></div>
    {message && <p className="adminMessage">{message}</p>}
    {orders.length === 0 ? <div className="emptyState">Ҳозирча буюртмалар йўқ.</div> : <div className="orderList">
      {orders.map(o=><article className="orderCard" key={o.id}>
        <div className="orderTop"><div><b>{o.orderNumber}</b><small>{new Date(o.createdAt).toLocaleString()}</small></div><strong>{Number(o.total).toLocaleString()} {o.currency}</strong></div>
        <div className="orderCustomer">{o.user.name || "Мижоз"} · {o.user.phone || "Телефон йўқ"}</div>
        <div className="orderAddress">{o.country}, {o.city}, {o.fullAddress}</div>
        <ul>{o.items.map(i=><li key={i.id}>{i.productName} × {i.quantity}</li>)}</ul>
        <div className="orderControls"><span>Ҳолати: <b>{statuses.find(s=>s[0]===o.status)?.[1] || o.status}</b></span>
          <select value={o.status} disabled={busy || ["DELIVERED","CANCELLED"].includes(o.status)} onChange={e=>changeStatus(o.id,e.target.value)}>
            {statuses.map(s=><option key={s[0]} value={s[0]}>{s[1]}</option>)}
          </select>
        </div>
      </article>)}
    </div>}
  </section>;
}
