"use client";
import { useEffect, useState } from "react";

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData: string;
        ready: () => void;
        expand: () => void;
      };
    };
  }
}

export function TelegramLogin() {
  const [state, setState] = useState("Telegram иловаси орқали киринг");
  const [loggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    const webApp = window.Telegram?.WebApp;
    if (!webApp) return;
    webApp.ready();
    webApp.expand();
    if (!webApp.initData) return;

    fetch("/api/auth/telegram", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ initData: webApp.initData })
    }).then(async response => {
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Кириш амалга ошмади");
      setLoggedIn(true);
      setState(`Хуш келибсиз, ${data.user.name || "PALMA мижози"}!`);
    }).catch(error => setState(error instanceof Error ? error.message : "Киришда хатолик"));
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setLoggedIn(false);
    setState("Аккаунтдан чиқдингиз.");
  }

  return <section className="loginCard">
    <div className="loginIcon">P</div>
    <h2>PALMA аккаунти</h2>
    <p>{state}</p>
    {loggedIn && <button className="filter" onClick={logout}>Чиқиш</button>}
    <small>Telegram авторизацияси фақат серверда имзоси текширилган initData орқали амалга ошади.</small>
  </section>;
}
