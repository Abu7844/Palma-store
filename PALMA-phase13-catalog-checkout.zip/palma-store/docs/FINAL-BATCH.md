# PALMA — қолган ишларнинг умумий йиғма пакети

## Бу пакетда амалда қўшилган
- 4 тил учун луғат асоси: ўзбек, рус, инглиз, араб; арабча RTL йўналиш helper.
- Telegram буюртма статус хабарлари учун 4 тилли шаблонлар ва умумий юбориш helper.
- Checkout'да серверда текшириладиган промокод: фаоллик, бошланиш/тугаш вақти, 1–100% чегирма.
- Буюртмада discount ва promotionId сақлаш.
- Фақат буюртмаси етказилган ва маҳсулотни олган мижоз шарҳ қолдира олади.
- Шарҳлар модерацияси: `/admin/reviews`.
- Ҳисобот CSV экспорти: `GET /api/admin/reports` (OWNER/ADMIN/ACCOUNTANT).

## База миграцияси
```bash
npx prisma migrate dev --name promotions_and_reports
npx prisma generate
```

## API
- `GET /api/reviews?productId=...`
- `POST /api/reviews`
- `GET /api/admin/reviews`
- `PATCH /api/admin/reviews`
- `GET /api/admin/reports?from=2026-01-01&to=2026-12-31`

## Ҳали ташқи ҳисоб/аккаунт талаб қиладиган ишлар
- Payme/Click/Uzcard/Visa ҳақиқий merchant API ва webhook адаптерлари.
- Telegram bot webhook'ни сервер доменига рўйхатдан ўтказиш ва bot token.
- Google OAuth client ва production callback URL.
- Email provider/SMTP.
- GPS учун курьер қурилмасидан рухсатли location update ва карта провайдери.
- Фото файлларни сақлаш учун S3/R2 ёки бошқа storage.
- Сервер, домен, SSL, production PostgreSQL ва secrets.

## Очиқ қолган муҳим ишлар (ишга туширишдан олдин шарт)
- Storefront ҳали каталог учун demo карточкалардан фойдаланади; реал API маҳсулотларига тўлиқ боғлаш ва checkout UI керак.
- Арабча RTL helper бор, аммо барча саҳифаларнинг тўлиқ таржимаси ва тил танлагичи ҳали йўқ.
- Telegram статус хабар helper тайёр, аммо мавжуд админ статус route'ига ҳар бир тил учун тўлиқ боғлаш керак.
- Excel/PDF экспорт эмас, ҳозирча CSV экспорт бор.
- Купон ҳозирча фоизли чегирма; buy-2-get-1, referral, loyalty ва совға логикаси ҳали тўлиқ эмас.
- Live chat, courier live map, upload pipeline ва автоматик валюталар курси йўқ.
- Тўлиқ unit/integration/e2e, dependency/security scan ва penetration test бажарилмаган.

## Текшириш
Бу муҳитда Node/npm орқали `npm install`, Prisma migrate ёки `npm run build` ишга туширилмаган. Шунинг учун архивни ишлаб чиқаришга тайёр деб ҳисобламанг. Аввал staging серверда миграция, build, API smoke tests ва провайдер sandbox тестларини ўтказинг.
