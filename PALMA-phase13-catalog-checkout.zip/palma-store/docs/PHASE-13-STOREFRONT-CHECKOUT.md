# PALMA — Phase 13: real catalogue and checkout

## What changed
- Storefront loads active products from `GET /api/products`; demo product cards were removed.
- Product images, Uzbek names/descriptions, prices and stock totals are shown when configured.
- Search works against the live product data.
- Cart supports quantity increase/decrease and totals.
- Checkout collects customer name, phone, email, country, city, address, postal code, promo code and comment.
- Checkout sends product IDs and quantities to the server. The server remains responsible for price, delivery, promotion and stock validation.
- Only cash on delivery is offered in the UI for now; online payment methods are intentionally hidden until provider integration exists.
- Successful orders display the generated order number.

## Required setup before live testing
1. Configure `DATABASE_URL` and `NEXTAUTH_SECRET` in `.env`.
2. Run all Prisma migrations documented in the earlier phase guides, then `npx prisma generate`.
3. Create at least one active warehouse.
4. Add active products with valid prices and images in the admin panel.
5. Add warehouse stock for each product.
6. Add a `DeliveryRate` for the exact country + city + currency used at checkout.
7. Configure `TELEGRAM_BOT_TOKEN` and `ADMIN_TELEGRAM_CHAT_ID` if admin Telegram alerts are desired.
8. Start the app and test a complete cash-on-delivery order.

## Important
This package has not been run through a production build or end-to-end test in this environment. Treat it as a development milestone, not a production deployment approval. Payment providers, full multilingual UI, customer support chat, image file storage and courier GPS remain later work.
