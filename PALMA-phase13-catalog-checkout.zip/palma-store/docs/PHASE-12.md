# PALMA — 12-босқич: тўлов webhook хавфсизлиги асоси

## Қўшилди
- Сервер webhook учун HMAC-SHA256 имзо текшируви.
- Транзакция ID, провайдер, сумма ва валюта мослигини текшириш.
- `PAID` ёки `FAILED` ҳолатини фақат имзоси текширилган сервер webhook орқали ўзгартириш.
- Бир хил event ID қайта келса, такрорий ишловни олдини олиш.
- Тўлов бошланганда `transactionId` жавобда қайтарилади.

## Муҳим: бу ҳали Payme'нинг расмий webhook протоколи эмас
`POST /api/payments/webhook` PALMA'нинг умумий ички webhook шартномасидир. Payme, Click, Uzcard ёки Visa'нинг расмий callback формати/имзоси бу endpoint'га ҳали мослаштирилмаган. Шунинг учун провайдердан келган тўғридан-тўғри callback'ни ҳозирча бу ерга юборманг. Аввал расмий провайдер адаптери ва callback parser ёзилиши шарт.

## Тест учун имзо
Имзо `raw request body` учун HMAC-SHA256 hex кўринишида ҳисобланади ва `x-palma-payment-signature` сарлавҳасида юборилади. Бу фақат PALMA ички интеграция шартномаси учун.

## Миграция ва ENV
```bash
npx prisma migrate dev --name payment_webhook_events
npx prisma generate
```
`.env` га тасодифий, узун махфий қиймат қўшинг:
```env
PALMA_PAYMENT_WEBHOOK_SECRET="replace-with-long-random-secret"
```

## Чекловлар
- Реал Payme merchant JSON-RPC `CheckPerformTransaction`, `CreateTransaction`, `PerformTransaction`, `CancelTransaction` протоколи ҳали йўқ.
- Click callback ва Visa/Uzcard PSP webhook'лари ҳали йўқ.
- Тўловни ишлаб чиқаришда ишлатишдан олдин провайдер sandbox тестлари, идемпотентлик ва хавфсизлик аудити шарт.
- Код `npm build` билан текширилмаган.
