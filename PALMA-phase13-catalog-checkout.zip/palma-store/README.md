# PALMA Store — starter project

A clean foundation for the PALMA multilingual commerce platform: Telegram Mini App, storefront, admin workspace, courier workflow, and API foundation.

## Current status
This is **Phase 1–2: runnable foundation and interactive storefront prototype**, not a production-ready store yet. Payment gateways, SMS/Google OAuth, Telegram webhook verification, live courier maps, shipping provider APIs, and production deployment require real provider credentials and configuration.

## Requirements
- Node.js 20+
- PostgreSQL 15+
- npm

## Run locally
```bash
cp .env.example .env.local
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```
Open http://localhost:3000

## Architecture
- `src/app`: Next.js app router, interactive storefront, admin and courier starter routes
- `src/components/storefront.tsx`: searchable catalogue, category filters and client-side cart prototype
- `src/app/api`: server API routes
- `prisma/schema.prisma`: relational data model
- `src/lib`: server-side validation and shared utilities

## Security decisions already built into the foundation
- Never trust prices, totals, discounts, stock, or shipping costs sent by the browser; recalculate on the server.
- Telegram Mini App identity must be verified server-side using Telegram `initData` and the bot token. `initDataUnsafe` is not authentication.
- Admin and courier endpoints must enforce authenticated role checks.
- Store secrets only in `.env.local` or a secrets manager.
- Payment status changes must come from verified provider callbacks, never from a client redirect.
- Keep an audit trail for inventory, order, and admin changes.

## Planned phases
1. Foundation and database (this package)
2. Storefront / Telegram Mini App UX and product catalogue
3. Secure checkout, shipping rules, order lifecycle, notifications
4. Admin panel, multi-warehouse inventory, reports
5. Courier PWA, maps, delivery proof
6. Payment integrations, production hardening and deployment

## Languages and currencies
UI language plan: Uzbek, Russian, English, Arabic (RTL support planned).
Currencies: UZS, USD, SAR plus admin-managed currencies and rates.

\n## Phase 3 — product administration\n- Public catalogue API: `GET /api/products`\n- Protected admin product list/create/archive API: `/api/admin/products`\n- Admin UI: `/admin`\n- Set a random 32+ character `ADMIN_ACCESS_KEY` in `.env.local`.\n- This is a temporary owner bootstrap gate. Replace with staff sessions, role-based access, CSRF protections, and complete audit logging before public production.\n- Product images currently accept HTTPS URLs; secure file upload storage remains a later integration.\n

## Phase 4 — secure checkout foundation
- `POST /api/checkout` validates customer details and cart lines.
- The server fetches product prices, validates active products, currency, warehouse stock and the country/city delivery tariff.
- Stock decrement, stock movement ledger and order creation run in one database transaction.
- Optional Telegram admin notification uses `TELEGRAM_BOT_TOKEN` + `ADMIN_TELEGRAM_CHAT_ID`.
- Before checkout can work, seed products, warehouse stock and delivery rates in the database.
- This is guest checkout by phone for the current prototype. Customer account sessions, customer-facing order history, verified payment callbacks, idempotency keys, rate limits, and order cancellation rules still need implementation before production.


## Phase 5 — order operations
- Admin order list: `GET /api/admin/orders` (protected by temporary admin key).
- Order status update: `PATCH /api/admin/orders/:id`.
- Enforced status transitions: NEW → CONFIRMED → PREPARING → SHIPPING → DELIVERED; cancellation is allowed before SHIPPING.
- If the customer has a linked Telegram chat ID, status changes trigger a Telegram message.
- The current guest checkout does not yet establish Telegram identity, so customer notifications require a verified Telegram account-linking flow before they can reach customers.
- Production requirements still include staff sessions/RBAC, audit logging, retryable notification queue, payment provider callbacks, and cancellation stock-restock workflow.


## Phase 6 — Telegram Mini App identity and customer account
- Telegram Mini App `initData` is validated on the server with Telegram WebApp HMAC and a 24-hour freshness limit.
- A signed, HttpOnly, SameSite=Lax session cookie is issued after verification.
- Customer profile endpoint: `GET /api/me`.
- Customer order history endpoint: `GET /api/my-orders`.
- Logout endpoint: `POST /api/auth/logout`.
- Configure `TELEGRAM_BOT_TOKEN` and a random `NEXTAUTH_SECRET` (32+ chars).
- Telegram login works only inside the configured Telegram Mini App. Google and email login providers are not implemented yet.
- Guest checkout orders do not automatically link to Telegram identity; a verified account-linking workflow is still needed.


## Phase 7 — courier workspace
- Admin-only courier assignment endpoint: `POST /api/admin/courier-assignments`.
- Courier's assigned orders: `GET /api/courier/orders` (requires signed-in COURIER account).
- Courier status updates: `PATCH /api/courier/orders/:id`.
- Courier can mark order as SHIPPING, then DELIVERED with a proof-photo URL.
- Courier can open customer address in Google Maps and call the customer.
- Admin must create/activate a User with role `COURIER` and assign an order.
- Photo upload and live GPS streaming are not implemented yet; current proof uses a URL field and map link is address search only.
